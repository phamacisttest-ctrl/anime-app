# Media3, Coil, Compose, Navigation and DataStore ship their own consumer rules.
# Keep readable stack traces for crash reports from Play Console.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# The playback service is referenced from the manifest.
-keep class com.elshatory.animeapp.playback.PlaybackService { *; }
