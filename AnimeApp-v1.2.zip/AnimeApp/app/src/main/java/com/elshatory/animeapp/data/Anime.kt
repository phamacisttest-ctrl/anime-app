
package com.elshatory.animeapp.data

enum class LicenseType {
    /**
     * Creative Commons Attribution 3.0.
     * يسمح بالاستخدام التجاري مع الالتزام بالنسب وشروط الترخيص.
     */
    CC_BY_3_0,

    /**
     * Creative Commons Attribution-ShareAlike 4.0.
     * يسمح بالاستخدام التجاري مع النسب وترخيص المواد المشتقة المشمولة
     * بالشروط نفسها عند توزيعها.
     */
    CC_BY_SA_4_0,

    /**
     * ترخيص يمنع الاستخدام التجاري.
     */
    CC_BY_NC,

    /**
     * الملك العام؛ يجب التحقق من وضع العمل القانوني أولاً.
     */
    PUBLIC_DOMAIN,

    /**
     * لم يتم التحقق من الترخيص أو مصدر الملف المستخدم.
     */
    UNVERIFIED
}

data class Anime(
    val id: Int,
    val title: String,
    val subtitle: String,
    val genre: String,
    val year: String,
    val rating: String,
    val episodes: String,
    val description: String,

    // لا تضف صورة هنا إلا بعد التحقق من حق استخدامها.
    val coverUrl: String?,

    // اتركه null حتى تتأكد من رابط الفيديو وحق إعادة توزيعه.
    val videoUrl: String?,

    val licenseType: LicenseType,
    val licenseUrl: String?,
    val officialSourceUrl: String,

    // نص النسب الذي يجب عرضه داخل التطبيق.
    val attribution: String,

    // لا تفعّل إعلانات المحتوى قبل التحقق من حقوقه.
    val monetizationVerified: Boolean,

    val accent: Long,
    /** Optional WebVTT / SRT subtitle file. The CC button only appears when this is set. */
    val subtitleUrl: String? = null
)

val LicenseType.label: String
    get() = when (this) {
        LicenseType.CC_BY_3_0 -> "CC BY 3.0"
        LicenseType.CC_BY_SA_4_0 -> "CC BY-SA 4.0"
        LicenseType.CC_BY_NC -> "CC BY-NC (non-commercial)"
        LicenseType.PUBLIC_DOMAIN -> "Public domain"
        LicenseType.UNVERIFIED -> "Unverified"
    }

object AnimeCatalog {
    val all: List<Anime> = listOf(
        Anime(
            id = 1,
            title = "Morevna: Episode 3",
            subtitle = "Independent Open-Source Anime",
            genre = "Sci-Fi",
            year = "2020",
            rating = "8.5",
            episodes = "Episode 3",
            description = "An independent science-fiction anime based on Russian fairy tales. This episode follows Marya Morevna and Ivan Tsarevitch.",
            // No verified cover yet. Add one only from the project's own press/media page.
            coverUrl = null,
            // TODO: put the direct file link from morevnaproject.org/anime/episode-3/ here.
            // It was previously pointing at Tears of Steel by mistake.
            videoUrl = null,
            licenseType = LicenseType.CC_BY_SA_4_0,
            licenseUrl = "https://creativecommons.org/licenses/by-sa/4.0/",
            officialSourceUrl = "https://morevnaproject.org/anime/episode-3/",
            attribution = "Morevna: Episode 3. Written and directed by Konstantin Dmitriev. Morevna Project. Licensed under CC BY-SA 4.0.",
            monetizationVerified = false,
            accent = 0xFFB94B42
        ),
        Anime(
            id = 2,
            title = "Sintel",
            subtitle = "Blender Open Movie",
            genre = "Fantasy",
            year = "2010",
            rating = "8.8",
            episodes = "Short Film",
            description = "A young woman searches for a dragon she raised. An independently produced animated fantasy short film.",
            coverUrl = null,
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            licenseType = LicenseType.CC_BY_3_0,
            licenseUrl = "https://creativecommons.org/licenses/by/3.0/",
            officialSourceUrl = "https://durian.blender.org/about/",
            attribution = "Sintel. © Blender Foundation. www.sintel.org. Licensed under Creative Commons Attribution 3.0.",
            monetizationVerified = false,
            accent = 0xFF4C6FA8
        ),
        Anime(
            id = 3,
            title = "Tears of Steel",
            subtitle = "Blender Open Movie",
            genre = "Sci-Fi",
            year = "2012",
            rating = "8.2",
            episodes = "Short Film",
            description = "A science-fiction short film combining live action and computer-generated visual effects.",
            coverUrl = null,
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            licenseType = LicenseType.CC_BY_3_0,
            licenseUrl = "https://creativecommons.org/licenses/by/3.0/",
            officialSourceUrl = "https://mango.blender.org/about/",
            attribution = "Tears of Steel. Blender Foundation. Licensed under Creative Commons Attribution 3.0.",
            monetizationVerified = false,
            accent = 0xFF777C8A
        )
    )
}
