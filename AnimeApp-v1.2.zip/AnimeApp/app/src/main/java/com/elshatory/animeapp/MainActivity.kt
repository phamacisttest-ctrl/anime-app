package com.elshatory.animeapp

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.elshatory.animeapp.data.AnimePreferences
import com.elshatory.animeapp.ui.AnimeApp
import com.elshatory.animeapp.ui.AnimeViewModel
import com.elshatory.animeapp.ui.theme.AnimeTheme
import com.elshatory.animeapp.ui.theme.isDarkFor

class MainActivity : ComponentActivity() {
    private val vm: AnimeViewModel by viewModels {
        AnimeViewModel.factory(AnimePreferences(applicationContext))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Keep the splash up until the saved theme is loaded, so there is no light/dark flash.
        installSplashScreen().setKeepOnScreenCondition { !vm.loaded.value }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val dark = isDarkFor(settings.themeMode)
            // Status/navigation bar icons follow the app theme, not just the system theme.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark }
                )
                onDispose { }
            }
            AnimeTheme(settings.themeMode) {
                AnimeApp(vm)
            }
        }
    }
}
