package com.elshatory.animeapp.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.media.AudioManager
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ClosedCaptionOff
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.elshatory.animeapp.data.Anime
import com.elshatory.animeapp.data.AppSettings
import com.elshatory.animeapp.playback.PlaybackService
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

// The player is always dark, independent of the app theme.
private val PAccent = Color(0xFFB8A1FF)
private val PMuted = Color(0xFFAAA7B8)
private val PBg = Color(0xFF0B0B12)

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

// AspectRatioFrameLayout: FIT = 0, FILL = 3, ZOOM = 4
private val RESIZE_MODES = listOf(0, 4, 3)
private val RESIZE_LABELS = listOf("Fit", "Zoom", "Stretch")

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

/** Position to remember: 0 (= start over) if the video is essentially finished. */
private fun resumeValue(player: Player): Long {
    val d = player.duration
    val p = player.currentPosition
    return if (d > 0 && p >= d - 5_000) 0L else p
}

@Composable
fun PlayerScreen(
    anime: Anime,
    settings: AppSettings,
    startPositionMs: Long,
    onSavePosition: (Long, Long) -> Unit,
    onBack: () -> Unit
) {
    val url = anime.videoUrl
    if (url.isNullOrBlank()) {
        NoSource(anime, onBack)
    } else {
        PlayerHost(anime, url, settings, startPositionMs, onSavePosition, onBack)
    }
}

/** Connects to [PlaybackService] and shows the player once the controller is ready. */
@Composable
private fun PlayerHost(
    anime: Anime,
    url: String,
    settings: AppSettings,
    startPositionMs: Long,
    onSavePosition: (Long, Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var failed by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                controller = future.get()
            } catch (e: Exception) {
                failed = true
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future) }
    }

    val c = controller
    when {
        c != null -> PlayerContent(c, anime, url, settings, startPositionMs, onSavePosition, onBack)
        failed -> Column(
            Modifier.fillMaxSize().background(PBg).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Couldn't start the player", color = Color.White, fontSize = 20.sp,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onBack) { Text("Back") }
        }
        else -> Box(Modifier.fillMaxSize().background(PBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PAccent)
        }
    }
}

@Composable
private fun NoSource(anime: Anime, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(PBg).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(anime.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "No verified video source is available for this title.",
            color = PMuted, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onBack) { Text("Back to details") }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun PlayerContent(
    player: Player,
    anime: Anime,
    videoUrl: String,
    settings: AppSettings,
    startPositionMs: Long,
    onSavePosition: (Long, Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // ---------- Player (a MediaController talking to PlaybackService) ----------
    LaunchedEffect(player) {
        val item = MediaItem.Builder()
            .setUri(videoUrl)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(anime.title)
                    .setArtist(anime.subtitle)
                    .build()
            )
            .apply {
                anime.subtitleUrl?.let { sub ->
                    val mime = if (sub.endsWith(".srt", true))
                        MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT
                    setSubtitleConfigurations(
                        listOf(
                            MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub))
                                .setMimeType(mime)
                                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                                .build()
                        )
                    )
                }
            }
            .build()
        val start = if (settings.resumePlayback && startPositionMs > 0) startPositionMs else 0L
        player.setMediaItem(item, start)
        player.setPlaybackSpeed(settings.defaultSpeed)
        player.playWhenReady = settings.autoplay
        player.prepare()
    }

    // ---------- UI state ----------
    var isPlaying by remember { mutableStateOf(false) }
    var playbackState by remember { mutableIntStateOf(Player.STATE_IDLE) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(settings.defaultSpeed) }
    var error by remember { mutableStateOf<PlaybackException?>(null) }
    var controlsVisible by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var resizeIdx by remember { mutableIntStateOf(0) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubPos by remember { mutableFloatStateOf(0f) }
    var inPip by remember { mutableStateOf(false) }
    var speedMenu by remember { mutableStateOf(false) }
    var seekFeedback by remember { mutableStateOf<String?>(null) }
    var feedbackKey by remember { mutableIntStateOf(0) }
    var hud by remember { mutableStateOf<String?>(null) }
    var subsOn by remember { mutableStateOf(true) }
    val readyOnce = remember { mutableStateOf(false) }

    var brightness by remember {
        val b = activity?.window?.attributes?.screenBrightness ?: -1f
        mutableFloatStateOf(if (b >= 0f) b else 0.5f)
    }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume)
    }

    fun saveNow() {
        if (readyOnce.value) onSavePosition(resumeValue(player), max(duration, player.duration))
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else {
            if (playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }

    fun seekBy(direction: Int) {
        val step = settings.seekStepSec * 1000L
        val upper = if (player.duration > 0) player.duration else Long.MAX_VALUE
        val target = (player.currentPosition + direction * step).coerceIn(0L, upper)
        player.seekTo(target)
        position = target
        seekFeedback = if (direction < 0) "◀◀  ${settings.seekStepSec}s" else "${settings.seekStepSec}s  ▶▶"
        feedbackKey++
    }

    fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity?.enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }
    val pipSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    // ---------- Player listener / release ----------
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlayingNow: Boolean) { isPlaying = isPlayingNow }
            override fun onPlaybackStateChanged(state: Int) {
                playbackState = state
                if (state == Player.STATE_READY) {
                    readyOnce.value = true
                    error = null
                    duration = max(player.duration, 0L)
                }
            }
            override fun onPlayerError(e: PlaybackException) { error = e }
            override fun onPlaybackParametersChanged(p: PlaybackParameters) { speed = p.speed }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            if (readyOnce.value) onSavePosition(resumeValue(player), player.duration.coerceAtLeast(0L))
            // Leaving the player screen ends playback (and removes the notification).
            player.stop()
            player.clearMediaItems()
        }
    }

    LaunchedEffect(player, subsOn) {
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn).build()
    }

    // Poll position + periodic save (~every 5 s)
    LaunchedEffect(player) {
        var ticks = 0
        while (true) {
            if (!scrubbing) position = player.currentPosition
            buffered = player.bufferedPosition
            if (duration <= 0 && player.duration > 0) duration = player.duration
            ticks++
            if (ticks % 20 == 0) saveNow()
            delay(250)
        }
    }

    // Auto-hide controls
    LaunchedEffect(controlsVisible, isPlaying, scrubbing, speedMenu) {
        if (controlsVisible && isPlaying && !scrubbing && !speedMenu) {
            delay(3_500)
            controlsVisible = false
        }
    }
    LaunchedEffect(feedbackKey) {
        if (seekFeedback != null) { delay(700); seekFeedback = null }
    }

    // Pause when app goes to background (but not into Picture-in-Picture); save on pause
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> saveNow()
                Lifecycle.Event.ON_STOP -> if (!settings.backgroundPlayback) player.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Picture-in-Picture state
    val componentActivity = activity as? ComponentActivity
    if (componentActivity != null) {
        DisposableEffect(componentActivity) {
            val consumer = Consumer<PictureInPictureModeChangedInfo> {
                inPip = it.isInPictureInPictureMode
            }
            componentActivity.addOnPictureInPictureModeChangedListener(consumer)
            onDispose { componentActivity.removeOnPictureInPictureModeChangedListener(consumer) }
        }
    }

    // Immersive mode + orientation + brightness cleanup
    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let { WindowInsetsControllerCompat(it, view) }
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        if (settings.landscapeOnStart) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
        }
    }

    val handleBack = {
        saveNow()
        onBack()
    }
    BackHandler {
        if (locked) controlsVisible = true else handleBack()
    }

    // ---------- UI ----------
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.player = player
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { pv ->
                pv.resizeMode = RESIZE_MODES[resizeIdx]
                pv.keepScreenOn = settings.keepScreenOn &&
                    (isPlaying || playbackState == Player.STATE_BUFFERING)
            },
            onRelease = { pv -> pv.player = null }
        )

        // Gesture layer: tap = toggle controls, double tap = seek, vertical drag = brightness / volume
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(locked, settings.seekStepSec) {
                    detectTapGestures(
                        onTap = { controlsVisible = !controlsVisible },
                        onDoubleTap = { offset ->
                            if (!locked) {
                                seekBy(if (offset.x < size.width / 2) -1 else 1)
                            }
                        }
                    )
                }
                .pointerInput(settings.gestures, locked) {
                    if (settings.gestures && !locked) {
                        var startX = 0f
                        detectVerticalDragGestures(
                            onDragStart = { startX = it.x },
                            onDragEnd = { hud = null },
                            onDragCancel = { hud = null }
                        ) { change, dragAmount ->
                            change.consume()
                            val delta = -dragAmount / size.height * 1.4f
                            if (startX < size.width / 2) {
                                brightness = (brightness + delta).coerceIn(0.02f, 1f)
                                activity?.window?.let { w ->
                                    val lp = w.attributes
                                    lp.screenBrightness = brightness
                                    w.attributes = lp
                                }
                                hud = "Brightness  ${(brightness * 100).roundToInt()}%"
                            } else {
                                volume = (volume + delta).coerceIn(0f, 1f)
                                audio.setStreamVolume(
                                    AudioManager.STREAM_MUSIC, (volume * maxVolume).roundToInt(), 0
                                )
                                hud = "Volume  ${(volume * 100).roundToInt()}%"
                            }
                        }
                    }
                }
        )

        // Buffering spinner
        if (playbackState == Player.STATE_BUFFERING && error == null && !inPip) {
            CircularProgressIndicator(Modifier.align(Alignment.Center).size(48.dp), color = PAccent)
        }

        // Double-tap feedback & gesture HUD
        seekFeedback?.let {
            Pill(it, Modifier.align(Alignment.Center))
        }
        hud?.let {
            Pill(it, Modifier.align(Alignment.TopCenter).padding(top = 56.dp))
        }

        // Controls
        AnimatedVisibility(
            visible = controlsVisible && !inPip && error == null,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            if (locked) {
                Box(Modifier.fillMaxSize()) {
                    IconButton(
                        onClick = { locked = false },
                        modifier = Modifier.align(Alignment.CenterStart).padding(16.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0x99000000))
                    ) { Icon(Icons.Filled.LockOpen, "Unlock controls", tint = Color.White) }
                }
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            listOf(Color(0xAA000000), Color(0x22000000), Color(0xCC000000))
                        )
                    )
                ) {
                    // Top bar
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = handleBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(anime.title, color = Color.White, fontWeight = FontWeight.Bold,
                                fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(anime.subtitle, color = Color(0xFFCCCCCC), fontSize = 12.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (anime.subtitleUrl != null) {
                            IconButton(onClick = { subsOn = !subsOn }) {
                                Icon(
                                    if (subsOn) Icons.Filled.ClosedCaption else Icons.Filled.ClosedCaptionOff,
                                    if (subsOn) "Turn subtitles off" else "Turn subtitles on",
                                    tint = if (subsOn) PAccent else Color.White
                                )
                            }
                        }
                        if (pipSupported) {
                            IconButton(onClick = { enterPip() }) {
                                Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White)
                            }
                        }
                        TextButton(onClick = { resizeIdx = (resizeIdx + 1) % RESIZE_MODES.size }) {
                            Icon(Icons.Filled.AspectRatio, null, tint = Color.White)
                            Spacer(Modifier.width(4.dp))
                            Text(RESIZE_LABELS[resizeIdx], color = Color.White, fontSize = 12.sp)
                        }
                        IconButton(onClick = {
                            activity?.requestedOrientation =
                                if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        }) { Icon(Icons.Filled.ScreenRotation, "Rotate", tint = Color.White) }
                    }

                    // Center transport controls
                    Row(
                        Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(28.dp)
                    ) {
                        IconButton(onClick = { seekBy(-1) }, Modifier.size(56.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.FastRewind, "Rewind", tint = Color.White,
                                    modifier = Modifier.size(30.dp))
                                Text("${settings.seekStepSec}s", color = Color.White, fontSize = 10.sp)
                            }
                        }
                        IconButton(
                            onClick = { togglePlay() },
                            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(50))
                                .background(PAccent.copy(alpha = 0.92f))
                        ) {
                            Icon(
                                when {
                                    playbackState == Player.STATE_ENDED -> Icons.Filled.Replay
                                    isPlaying -> Icons.Filled.Pause
                                    else -> Icons.Filled.PlayArrow
                                },
                                if (isPlaying) "Pause" else "Play",
                                tint = Color(0xFF21163A), modifier = Modifier.size(40.dp)
                            )
                        }
                        IconButton(onClick = { seekBy(1) }, Modifier.size(56.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.FastForward, "Forward", tint = Color.White,
                                    modifier = Modifier.size(30.dp))
                                Text("${settings.seekStepSec}s", color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }

                    // Bottom bar
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmt(if (scrubbing) scrubPos.toLong() else position),
                                color = Color.White, fontSize = 12.sp)
                            Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            LinearProgressIndicator(
                                progress = { (buffered.toFloat() / max(duration.toFloat(), 1f)).coerceIn(0f, 1f) },
                                modifier = Modifier.align(Alignment.Center).fillMaxWidth()
                                    .padding(horizontal = 8.dp).height(4.dp).clip(RoundedCornerShape(50)),
                                color = Color(0x66FFFFFF), trackColor = Color(0x33FFFFFF)
                            )
                            Slider(
                                value = (if (scrubbing) scrubPos else position.toFloat())
                                    .coerceIn(0f, max(duration.toFloat(), 1f)),
                                onValueChange = { scrubbing = true; scrubPos = it },
                                onValueChangeFinished = {
                                    player.seekTo(scrubPos.toLong())
                                    position = scrubPos.toLong()
                                    scrubbing = false
                                },
                                valueRange = 0f..max(duration.toFloat(), 1f),
                                colors = SliderDefaults.colors(
                                    thumbColor = PAccent,
                                    activeTrackColor = PAccent,
                                    inactiveTrackColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                            }
                            Text(fmt(duration), color = Color.White, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                TextButton(onClick = { speedMenu = true }) {
                                    Icon(Icons.Filled.Speed, null, tint = Color.White)
                                    Spacer(Modifier.width(6.dp))
                                    Text(speedLabel(speed), color = Color.White)
                                }
                                DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                                    SPEEDS.forEach { s ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    speedLabel(s),
                                                    fontWeight = if (s == speed) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (s == speed) MaterialTheme.colorScheme.primary else Color.Unspecified
                                                )
                                            },
                                            onClick = { player.setPlaybackSpeed(s); speedMenu = false }
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { locked = true; controlsVisible = true }) {
                                Icon(Icons.Filled.Lock, null, tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("Lock", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Error state
        error?.let { e ->
            Column(
                Modifier.fillMaxSize().background(Color(0xE60B0B12)).padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Couldn't play this video", color = Color.White,
                    fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    errorMessage(e),
                    color = PMuted, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        error = null
                        player.prepare()
                        player.play()
                    }) { Text("Retry") }
                    OutlinedButton(onClick = handleBack) { Text("Back") }
                }
            }
        }
    }
}

@Composable
private fun Pill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(50)).background(Color(0xB3000000))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

private fun speedLabel(s: Float): String =
    if (s == s.toInt().toFloat()) "${s.toInt()}.0×" else "${s}×"

private fun errorMessage(e: PlaybackException): String = when (e.errorCode) {
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
        "Check your internet connection and try again."
    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
        "The video file isn't available at its source right now."
    PlaybackException.ERROR_CODE_DECODING_FAILED,
    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
        "This device couldn't decode the video."
    else -> "Something went wrong (${e.errorCodeName})."
}
