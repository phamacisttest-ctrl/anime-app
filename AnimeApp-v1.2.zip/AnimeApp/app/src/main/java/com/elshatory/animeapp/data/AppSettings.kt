package com.elshatory.animeapp.data

/** Where the user stopped in a video; used for "Continue watching". */
data class WatchProgress(val positionMs: Long, val durationMs: Long) {
    val fraction: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val remainingMs: Long
        get() = (durationMs - positionMs).coerceAtLeast(0L)
}

enum class ThemeMode { SYSTEM, DARK, LIGHT, BLACK }

/** Parsing/serialising of saved progress, kept pure so it can be unit-tested. */
internal fun parseProgress(raw: String?): Map<Int, WatchProgress> =
    raw.orEmpty().split(",").mapNotNull { entry ->
        val parts = entry.split(":")
        val id = parts.getOrNull(0)?.toIntOrNull()
        val pos = parts.getOrNull(1)?.toLongOrNull()
        val dur = parts.getOrNull(2)?.toLongOrNull() ?: 0L   // older saves had no duration
        if (id != null && pos != null) id to WatchProgress(pos, dur) else null
    }.toMap()

internal fun serializeProgress(map: Map<Int, WatchProgress>): String =
    map.entries.joinToString(",") { "${it.key}:${it.value.positionMs}:${it.value.durationMs}" }

/** All user-configurable options. Persisted by [AnimePreferences]. */
data class AppSettings(
    val autoplay: Boolean = true,
    val resumePlayback: Boolean = true,
    val defaultSpeed: Float = 1f,
    val seekStepSec: Int = 10,
    val keepScreenOn: Boolean = true,
    val gestures: Boolean = true,
    val landscapeOnStart: Boolean = false,
    val showCovers: Boolean = true,
    val backgroundPlayback: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)
