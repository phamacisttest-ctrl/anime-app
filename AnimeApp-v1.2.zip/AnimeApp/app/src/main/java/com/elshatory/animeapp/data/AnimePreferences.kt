package com.elshatory.animeapp.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "anime_app_preferences")

class AnimePreferences(private val context: Context) {
    private val favoritesKey = stringSetPreferencesKey("favorite_anime_ids")
    private val recentKey = stringPreferencesKey("recent_anime_ids")
    private val positionsKey = stringPreferencesKey("playback_positions")

    private val autoplayKey = booleanPreferencesKey("autoplay")
    private val resumeKey = booleanPreferencesKey("resume_playback")
    private val speedKey = floatPreferencesKey("default_speed")
    private val seekKey = intPreferencesKey("seek_step_sec")
    private val keepOnKey = booleanPreferencesKey("keep_screen_on")
    private val gesturesKey = booleanPreferencesKey("gestures")
    private val landscapeKey = booleanPreferencesKey("landscape_on_start")
    private val coversKey = booleanPreferencesKey("show_covers")

    val favorites: Flow<Set<Int>> = context.dataStore.data.map { prefs ->
        prefs[favoritesKey].orEmpty().mapNotNull(String::toIntOrNull).toSet()
    }

    val recent: Flow<List<Int>> = context.dataStore.data.map { prefs ->
        prefs[recentKey].orEmpty().split(",").mapNotNull(String::toIntOrNull)
    }

    /** animeId -> where the user stopped (position + total duration, in ms). */
    val positions: Flow<Map<Int, WatchProgress>> = context.dataStore.data.map { prefs ->
        parseProgress(prefs[positionsKey])
    }

    private val bgPlayKey = booleanPreferencesKey("background_playback")
    private val themeKey = stringPreferencesKey("theme_mode")

    private fun readSettings(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            autoplay = p[autoplayKey] ?: d.autoplay,
            resumePlayback = p[resumeKey] ?: d.resumePlayback,
            defaultSpeed = p[speedKey] ?: d.defaultSpeed,
            seekStepSec = p[seekKey] ?: d.seekStepSec,
            keepScreenOn = p[keepOnKey] ?: d.keepScreenOn,
            gestures = p[gesturesKey] ?: d.gestures,
            landscapeOnStart = p[landscapeKey] ?: d.landscapeOnStart,
            showCovers = p[coversKey] ?: d.showCovers,
            backgroundPlayback = p[bgPlayKey] ?: d.backgroundPlayback,
            themeMode = p[themeKey]?.let { name ->
                ThemeMode.values().firstOrNull { it.name == name }
            } ?: d.themeMode
        )
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { readSettings(it) }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p ->
            val n = transform(readSettings(p))
            p[autoplayKey] = n.autoplay
            p[resumeKey] = n.resumePlayback
            p[speedKey] = n.defaultSpeed
            p[seekKey] = n.seekStepSec
            p[keepOnKey] = n.keepScreenOn
            p[gesturesKey] = n.gestures
            p[landscapeKey] = n.landscapeOnStart
            p[coversKey] = n.showCovers
            p[bgPlayKey] = n.backgroundPlayback
            p[themeKey] = n.themeMode.name
        }
    }

    suspend fun toggleFavorite(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[favoritesKey].orEmpty().toMutableSet()
            if (!current.add(id.toString())) current.remove(id.toString())
            prefs[favoritesKey] = current
        }
    }

    suspend fun markWatched(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[recentKey].orEmpty().split(",")
                .filter { it.isNotBlank() }.toMutableList()
            current.remove(id.toString())
            current.add(0, id.toString())
            prefs[recentKey] = current.take(20).joinToString(",")
        }
    }

    /** Saves progress; a position <= 0 clears it (finished / restart). */
    suspend fun savePosition(id: Int, positionMs: Long, durationMs: Long) {
        context.dataStore.edit { prefs ->
            val map = parseProgress(prefs[positionsKey]).toMutableMap()
            if (positionMs <= 0L) map.remove(id) else map[id] = WatchProgress(positionMs, durationMs)
            prefs[positionsKey] = serializeProgress(map)
        }
    }

    suspend fun clearRecent() { context.dataStore.edit { it.remove(recentKey) } }
    suspend fun clearFavorites() { context.dataStore.edit { it.remove(favoritesKey) } }
    suspend fun clearPositions() { context.dataStore.edit { it.remove(positionsKey) } }
}
