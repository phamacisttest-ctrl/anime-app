package com.elshatory.animeapp.ui

import android.content.Intent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil3.compose.AsyncImage
import com.elshatory.animeapp.data.Anime
import com.elshatory.animeapp.data.AnimeCatalog
import com.elshatory.animeapp.data.WatchProgress
import com.elshatory.animeapp.data.label
import com.elshatory.animeapp.ui.player.PlayerScreen
import com.elshatory.animeapp.ui.theme.LocalPalette

// Theme-aware palette (see ui/theme/AnimeTheme.kt). Same names as before, now composable getters.
internal val Bg: Color @Composable get() = LocalPalette.current.bg
internal val Panel: Color @Composable get() = LocalPalette.current.panel
internal val Accent: Color @Composable get() = LocalPalette.current.accent
internal val OnAccent: Color @Composable get() = LocalPalette.current.onAccent
internal val Muted: Color @Composable get() = LocalPalette.current.muted
internal val TextPrimary: Color @Composable get() = LocalPalette.current.text
internal val ChipBg: Color @Composable get() = LocalPalette.current.chip
internal val Outline: Color @Composable get() = LocalPalette.current.outline

/** Whether cover images should be loaded (user setting "Show cover images"). */
private val LocalShowCovers = compositionLocalOf { true }

private fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

/** Cover art, or a tidy gradient placeholder when there is no verified image / data saver is on. */
@Composable
private fun Cover(anime: Anime, modifier: Modifier = Modifier) {
    val url = anime.coverUrl
    val show = LocalShowCovers.current
    if (url != null && show) {
        AsyncImage(model = url, contentDescription = anime.title,
            modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        val accent = Color(anime.accent)
        Box(
            modifier.background(Brush.linearGradient(listOf(accent, Bg))),
            contentAlignment = Alignment.Center
        ) {
            Text(anime.title.take(1).uppercase(), color = TextPrimary.copy(alpha = 0.55f),
                fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun AnimeApp(vm: AnimeViewModel) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val positions by vm.positions.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val immersive = route.startsWith("player/")
    val hideBar = immersive || route.startsWith("details/") || route == "licenses" || route == "privacy"

    val online = rememberIsOnline()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(online, immersive) {
        if (!online && !immersive) {
            snackbar.showSnackbar("You're offline — videos and images need a connection",
                duration = SnackbarDuration.Indefinite)
        } else {
            snackbar.currentSnackbarData?.dismiss()
        }
    }

    CompositionLocalProvider(LocalShowCovers provides settings.showCovers) {
        Scaffold(
            containerColor = Bg,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (!hideBar) {
                    NavigationBar(containerColor = Panel, contentColor = TextPrimary) {
                        val tabs = listOf(
                            Triple("home", "Home", Icons.Filled.Home),
                            Triple("discover", "Discover", Icons.Filled.Explore),
                            Triple("favorites", "Saved", Icons.Filled.Favorite),
                            Triple("settings", "Settings", Icons.Filled.Settings)
                        )
                        tabs.forEach { (dest, label, icon) ->
                            NavigationBarItem(
                                selected = route == dest,
                                onClick = {
                                    nav.navigate(dest) {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Accent,
                                    selectedTextColor = Accent,
                                    indicatorColor = ChipBg,
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = nav, startDestination = "home",
                // The player draws edge-to-edge, everything else respects system bars.
                modifier = if (immersive) Modifier else Modifier.padding(padding),
                enterTransition = { fadeIn(tween(220)) },
                exitTransition = { fadeOut(tween(160)) },
                popEnterTransition = { fadeIn(tween(220)) },
                popExitTransition = { fadeOut(tween(160)) }
            ) {
                composable("home") {
                    HomeScreen(
                        favorites = favorites, recent = recent, progress = positions,
                        onToggleFavorite = vm::toggleFavorite,
                        onMarkWatched = vm::markWatched,
                        onContinue = { a ->
                            vm.markWatched(a.id)
                            nav.navigate("player/${a.id}")
                        },
                        onAnimeClick = { nav.navigate("details/${it.id}") }
                    )
                }
                composable("discover") {
                    DiscoverScreen(favorites, vm::toggleFavorite) { nav.navigate("details/${it.id}") }
                }
                composable("favorites") {
                    val saved = AnimeCatalog.all.filter { it.id in favorites }
                    SimpleListScreen("Your watchlist", "Your saved anime lives here.", saved,
                        favorites, vm::toggleFavorite) { nav.navigate("details/${it.id}") }
                }
                composable("settings") {
                    SettingsScreen(
                        settings = settings,
                        onUpdate = { t -> vm.updateSettings(t) },
                        onClearRecent = { vm.clearRecent() },
                        onClearFavorites = { vm.clearFavorites() },
                        onClearPositions = { vm.clearPositions() },
                        onOpenLicenses = { nav.navigate("licenses") },
                        onOpenPrivacy = { nav.navigate("privacy") }
                    )
                }
                composable("licenses") { LicensesScreen { nav.popBackStack() } }
                composable("privacy") { PrivacyScreen { nav.popBackStack() } }
                composable("details/{animeId}",
                    arguments = listOf(navArgument("animeId") { type = NavType.IntType })) { backStack ->
                    val id = backStack.arguments?.getInt("animeId")
                    val anime = AnimeCatalog.all.firstOrNull { it.id == id }
                    if (anime != null) {
                        DetailsScreen(
                            anime = anime,
                            isFavorite = anime.id in favorites,
                            onFavorite = { vm.toggleFavorite(anime.id) },
                            onPlay = {
                                vm.markWatched(anime.id)
                                nav.navigate("player/${anime.id}")
                            },
                            resumeMs = if (settings.resumePlayback) positions[anime.id]?.positionMs ?: 0L else 0L,
                            favorites = favorites,
                            onToggleFavorite = vm::toggleFavorite,
                            onRelatedClick = { nav.navigate("details/${it.id}") },
                            onBack = { nav.popBackStack() }
                        )
                    }
                }
                composable("player/{animeId}",
                    arguments = listOf(navArgument("animeId") { type = NavType.IntType })) { backStack ->
                    val id = backStack.arguments?.getInt("animeId")
                    val anime = AnimeCatalog.all.firstOrNull { it.id == id }
                    if (anime != null) {
                        PlayerScreen(
                            anime = anime,
                            settings = settings,
                            startPositionMs = positions[anime.id]?.positionMs ?: 0L,
                            onSavePosition = { pos, dur -> vm.savePosition(anime.id, pos, dur) },
                            onBack = { nav.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    favorites: Set<Int>,
    recent: List<Int>,
    progress: Map<Int, WatchProgress>,
    onToggleFavorite: (Int) -> Unit,
    onMarkWatched: (Int) -> Unit,
    onContinue: (Anime) -> Unit,
    onAnimeClick: (Anime) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = AnimeCatalog.all.filter { it.title.contains(query,
        true) || it.genre.contains(query, true) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp,
            top = 22.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier =
                Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("ANIME", color = Accent, fontSize = 12.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Discover your", fontSize = 28.sp, fontWeight =
                        FontWeight.Bold, color = TextPrimary)
                    Text("next obsession.", fontSize = 28.sp, fontWeight =
                        FontWeight.Bold, color = Accent)
                }
                Box(Modifier.size(46.dp).clip(CircleShape)
                    .background(ChipBg),
                    contentAlignment = Alignment.Center) {
                    Text("ア", color = Accent, fontSize = 24.sp,
                        fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search anime or genre…", color = Muted) },
                leadingIcon = { Icon(Icons.Filled.Search,
                    null, tint = Muted) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent, unfocusedBorderColor = Outline,
                    focusedContainerColor = Panel, unfocusedContainerColor = Panel,
                    focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary
                )
            )
        }
        if (query.isBlank()) {
            item { SectionTitle("Featured this week", "EDITOR'S PICK") }
            item {
                FeaturedCard(AnimeCatalog.all.first(), favorites.contains(1),
                    { onToggleFavorite(1) }) {
                    onAnimeClick(AnimeCatalog.all.first())
                }
            }
            val continuing = recent
                .mapNotNull { id -> AnimeCatalog.all.firstOrNull { it.id == id } }
                .filter { (progress[it.id]?.positionMs ?: 0L) > 0L && it.videoUrl != null }
            if (continuing.isNotEmpty()) {
                item { SectionTitle("Continue watching", "RESUME") }
                items(continuing, key = { "continue-${it.id}" }) { a ->
                    ContinueCard(a, progress.getValue(a.id)) { onContinue(a) }
                }
            }
            item { SectionTitle("Trending now", "POPULAR") }
        } else {
            item { SectionTitle("Search results", "${filtered.size} TITLES") }
        }
        if (filtered.isEmpty()) {
            item { EmptyState("No anime found", "Try another title or genre.") }
        } else {
            items(filtered, key = { it.id }) { anime ->
                AnimeRow(anime, anime.id in favorites,
                    { onToggleFavorite(anime.id) }) { onAnimeClick(anime) }
            }
        }
        if (recent.isNotEmpty() && query.isBlank()) {
            item { SectionTitle("Recently opened", "CONTINUE") }
            items(recent.mapNotNull { id -> AnimeCatalog.all.firstOrNull { it
                .id == id } }.distinctBy { it.id }) { anime ->
                AnimeRow(anime, anime.id in favorites,
                    { onToggleFavorite(anime.id) }) { onAnimeClick(anime) }
            }
        }
    }
}

@Composable
private fun DiscoverScreen(
    favorites: Set<Int>,
    onToggleFavorite: (Int) -> Unit,
    onAnimeClick: (Anime) -> Unit
) {
    var selected by remember { mutableStateOf("All") }
    val genres = listOf("All") + AnimeCatalog.all.map { it.genre }.distinct()
    var sort by remember { mutableStateOf("Top rated") }
    val results = AnimeCatalog.all.filter { selected == "All" || it.genre == selected }
    val sorted = when (sort) {
        "Newest" -> results.sortedByDescending { it.year }
        "A–Z" -> results.sortedBy { it.title }
        else -> results.sortedByDescending { it.rating.toFloatOrNull() ?: 0f }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Explore", color = TextPrimary, fontSize = 30.sp,
                fontWeight = FontWeight.Bold)
            Text("Find a story worth staying up for.", color = Muted)
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                genres.forEach { genre ->
                    FilterChip(
                        selected = selected == genre,
                        onClick = { selected = genre },
                        label = { Text(genre) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = OnAccent,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sort", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(end = 4.dp))
                listOf("Top rated", "Newest", "A–Z").forEach { option ->
                    FilterChip(
                        selected = sort == option,
                        onClick = { sort = option },
                        label = { Text(option) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = OnAccent,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }
        items(sorted, key = { it.id }) { anime ->
            AnimeRow(anime, anime.id in favorites,
                { onToggleFavorite(anime.id) }) { onAnimeClick(anime) }
        }
    }
}

@Composable
private fun SimpleListScreen(
    title: String,
    subtitle: String,
    items: List<Anime>,
    favorites: Set<Int>,
    onToggleFavorite: (Int) -> Unit,
    onAnimeClick: (Anime) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(title, color = TextPrimary, fontSize = 30.sp,
                fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted)
        }
        if (items.isEmpty()) {
            item { EmptyState("Nothing saved yet",
                "Tap the bookmark on an anime to keep it here.") }
        } else {
            items(items, key = { it.id }) { anime ->
                AnimeRow(anime, anime.id in favorites,
                    { onToggleFavorite(anime.id) }) { onAnimeClick(anime) }
            }
        }
    }
}

@Composable
private fun FeaturedCard(anime: Anime, isFavorite: Boolean,
                         onFavorite: () -> Unit, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(390.dp)
            .clip(RoundedCornerShape(26.dp)).clickable(onClick = onClick)
    ) {
        Cover(anime, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush
            .verticalGradient(listOf(Color.Transparent,
                Bg.copy(alpha = 0.94f), Bg))))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Surface(color = Accent, shape = RoundedCornerShape(7.dp)) {
                Text("FEATURED", color = OnAccent,
                    fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp, modifier = Modifier
                        .padding(horizontal = 10.dp, vertical = 6.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(anime.title, color = TextPrimary, fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold)
            Text("${anime.year}  •  ${anime.genre}  •  ★ ${anime.rating}",
                color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement =
                Arrangement.spacedBy(10.dp)) {
                Button(onClick = onClick, colors = ButtonDefaults
                    .buttonColors(containerColor = Accent, contentColor =
                        OnAccent)) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Explore")
                }
                IconButton(onClick = onFavorite, modifier =
                    Modifier.background(Color(0x6620202B), CircleShape)) {
                    Icon(if (isFavorite) Icons.Filled
                        .Bookmark else Icons.Filled.BookmarkBorder, null,
                        tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun AnimeRow(anime: Anime, isFavorite: Boolean,
                     onFavorite: () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(Panel).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(92.dp).height(122.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(Color(anime.accent))) {
            Cover(anime, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush
                .verticalGradient(listOf(Color.Transparent,
                    Color(0x66000000)))))
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement =
            Arrangement.spacedBy(5.dp)) {
            Text(anime.title, color = TextPrimary, fontSize = 16.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(anime.subtitle, color = Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${anime.year}  •  ${anime.genre}", color = Muted, fontSize = 11.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, null,
                    tint = Color(0xFFFFC857), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text(anime.rating, color = TextPrimary, fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(8.dp))
                Text(anime.episodes, color = Muted, fontSize = 11.sp)
            }
        }
        IconButton(onClick = onFavorite) {
            Icon(if (isFavorite) Icons.Filled.Bookmark else Icons.Filled
                .BookmarkBorder, contentDescription = "Save anime",
                tint = if (isFavorite) Accent else Muted)
        }
    }
}

@Composable
private fun DetailsScreen(
    anime: Anime,
    isFavorite: Boolean,
    onFavorite: () -> Unit,
    onPlay: () -> Unit,
    resumeMs: Long,
    favorites: Set<Int>,
    onToggleFavorite: (Int) -> Unit,
    onRelatedClick: (Anime) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val related = AnimeCatalog.all.filter { it.id != anime.id }
        .sortedByDescending { it.genre == anime.genre }.take(3)
    val uriHandler = LocalUriHandler.current
    val playLabel = when {
        anime.videoUrl == null -> "No verified source yet"
        resumeMs > 0 -> "Resume from ${formatTime(resumeMs)}"
        else -> "Start watching"
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 26.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(440.dp)) {
                Cover(anime, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush
                    .verticalGradient(listOf(Color(0x33000000), Bg))))
                TextButton(onClick = onBack, modifier = Modifier.align(Alignment
                    .TopStart).padding(12.dp)) {
                    Text("‹  Back", color = Color.White, fontSize = 17.sp)
                }
                Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                    Text(anime.genre.uppercase(), color = Accent,
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(anime.title, color = TextPrimary,
                        fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${anime.year}  •  ★ ${anime.rating}  •  ${anime.episodes}",
                        color = Muted)
                }
            }
        }
        item {
            Column(Modifier.padding(20.dp), verticalArrangement =
                Arrangement.spacedBy(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = onPlay, enabled = anime.videoUrl != null, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent,
                            contentColor = OnAccent)) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(playLabel)
                    }
                    OutlinedButton(onClick = onFavorite) {
                        Icon(if (isFavorite) Icons.Filled
                            .Bookmark else Icons.Filled.BookmarkBorder,
                            null)
                        Spacer(Modifier.width(5.dp))
                        Text(if (isFavorite) "Saved" else "Save")
                    }
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, anime.title)
                            putExtra(Intent.EXTRA_TEXT, "${anime.title} — ${anime.officialSourceUrl}")
                        }
                        context.startActivity(Intent.createChooser(send, "Share ${anime.title}"))
                    }) { Icon(Icons.Filled.Share, contentDescription = "Share", tint = TextPrimary) }
                }
                Text("Synopsis", color = TextPrimary, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold)
                Text(anime.description, color = Muted, fontSize = 15.sp,
                    lineHeight = 23.sp)
                Text("License", color = TextPrimary, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold)
                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(anime.licenseType.label, color = Accent, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold)
                        Text(anime.attribution, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            anime.licenseUrl?.let { u ->
                                OutlinedButton(onClick = { uriHandler.openUri(u) }) { Text("License") }
                            }
                            OutlinedButton(onClick = { uriHandler.openUri(anime.officialSourceUrl) }) {
                                Text("Source")
                            }
                        }
                    }
                }
                Text("Episodes", color = TextPrimary, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold)
                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = anime.videoUrl != null, onClick = onPlay)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ChipBg),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.PlayArrow,
                                null, tint = Accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(anime.episodes,
                                color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text(if (anime.videoUrl != null) "Tap to play" else "Coming soon", color = Muted, fontSize = 12.sp)
                        }
                        Text("›", color = Muted, fontSize = 26.sp)
                    }
                }
            }
        }
        if (related.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Spacer(Modifier.height(4.dp))
                    Text("More like this", color = TextPrimary, fontSize = 20.sp,
                        fontWeight = FontWeight.Bold)
                    related.forEach { r ->
                        AnimeRow(r, r.id in favorites, { onToggleFavorite(r.id) }) { onRelatedClick(r) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueCard(anime: Anime, progress: WatchProgress, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(120.dp).height(68.dp).clip(RoundedCornerShape(12.dp))) {
            Cover(anime, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color(0x55000000)))
            Icon(Icons.Filled.PlayArrow, contentDescription = "Resume",
                tint = Color.White, modifier = Modifier.align(Alignment.Center).size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(anime.title, color = TextPrimary, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            LinearProgressIndicator(
                progress = { progress.fraction },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)),
                color = Accent, trackColor = ChipBg
            )
            Text(
                if (progress.durationMs > 0) "${formatTime(progress.remainingMs)} left"
                else "Resume from ${formatTime(progress.positionMs)}",
                color = Muted, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String, tag: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextPrimary, fontSize = 20.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(tag, color = Accent, fontSize = 10.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.BookmarkBorder, null,
            tint = Accent, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}
