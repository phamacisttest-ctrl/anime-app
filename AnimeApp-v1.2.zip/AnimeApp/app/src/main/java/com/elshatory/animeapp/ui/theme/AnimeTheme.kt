package com.elshatory.animeapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.elshatory.animeapp.data.ThemeMode

@Immutable
data class AnimePalette(
    val bg: Color,
    val panel: Color,
    val accent: Color,
    val onAccent: Color,
    val muted: Color,
    val text: Color,
    val chip: Color,
    val outline: Color,
    val isDark: Boolean
)

val DarkPalette = AnimePalette(
    bg = Color(0xFF0B0B12), panel = Color(0xFF15151F),
    accent = Color(0xFFB8A1FF), onAccent = Color(0xFF21163A),
    muted = Color(0xFFAAA7B8), text = Color(0xFFF4F1FA),
    chip = Color(0xFF302744), outline = Color(0xFF333140), isDark = true
)

/** True-black variant for OLED screens. */
val BlackPalette = DarkPalette.copy(bg = Color.Black, panel = Color(0xFF101016))

val LightPalette = AnimePalette(
    bg = Color(0xFFF7F5FC), panel = Color.White,
    accent = Color(0xFF6B4FD8), onAccent = Color.White,
    muted = Color(0xFF625E73), text = Color(0xFF1B1830),
    chip = Color(0xFFE8E2FA), outline = Color(0xFFD5CFE6), isDark = false
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

@Composable
fun isDarkFor(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.DARK, ThemeMode.BLACK -> true
    ThemeMode.LIGHT -> false
}

@Composable
fun AnimeTheme(mode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = isDarkFor(mode)
    val palette = when {
        mode == ThemeMode.BLACK -> BlackPalette
        dark -> DarkPalette
        else -> LightPalette
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.accent, onPrimary = palette.onAccent,
            secondary = Color(0xFF83D7D0),
            background = palette.bg, surface = palette.panel,
            surfaceVariant = palette.chip,
            onBackground = palette.text, onSurface = palette.text,
            onSurfaceVariant = palette.muted, outline = palette.outline
        )
    } else {
        lightColorScheme(
            primary = palette.accent, onPrimary = palette.onAccent,
            secondary = Color(0xFF1F8F87),
            background = palette.bg, surface = palette.panel,
            surfaceVariant = palette.chip,
            onBackground = palette.text, onSurface = palette.text,
            onSurfaceVariant = palette.muted, outline = palette.outline
        )
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
