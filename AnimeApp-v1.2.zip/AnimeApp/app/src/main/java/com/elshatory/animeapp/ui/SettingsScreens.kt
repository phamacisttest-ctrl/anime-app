package com.elshatory.animeapp.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elshatory.animeapp.data.AnimeCatalog
import com.elshatory.animeapp.AppInfo
import com.elshatory.animeapp.data.AppSettings
import com.elshatory.animeapp.data.ThemeMode
import com.elshatory.animeapp.data.label


@Composable
fun SettingsScreen(
    settings: AppSettings,
    onUpdate: ((AppSettings) -> AppSettings) -> Unit,
    onClearRecent: () -> Unit,
    onClearFavorites: () -> Unit,
    onClearPositions: () -> Unit,
    onOpenLicenses: () -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val versionName = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }
            .getOrNull().orEmpty()
    }
    // Android 13+: the media notification needs this permission. Playback itself works without it.
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Settings", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Make your anime space feel like yours.", color = Muted)
        }

        item { Header("Appearance") }
        item {
            ChoiceRow(
                "Theme",
                listOf(
                    "System" to ThemeMode.SYSTEM, "Dark" to ThemeMode.DARK,
                    "Light" to ThemeMode.LIGHT, "AMOLED black" to ThemeMode.BLACK
                ),
                settings.themeMode
            ) { v -> onUpdate { it.copy(themeMode = v) } }
        }

        item { Header("Playback") }
        item {
            SwitchRow("Autoplay", "Start playing as soon as the player opens", settings.autoplay) { v ->
                onUpdate { it.copy(autoplay = v) }
            }
        }
        item {
            SwitchRow("Resume where you left off", "Continue from your last position", settings.resumePlayback) { v ->
                onUpdate { it.copy(resumePlayback = v) }
            }
        }
        item {
            SwitchRow(
                "Background playback",
                "Keep audio playing when the app is minimised or the screen is off",
                settings.backgroundPlayback
            ) { v ->
                onUpdate { it.copy(backgroundPlayback = v) }
                if (v && Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        item {
            SwitchRow("Gesture controls", "Swipe up/down: left = brightness, right = volume", settings.gestures) { v ->
                onUpdate { it.copy(gestures = v) }
            }
        }
        item {
            SwitchRow("Keep screen on", "Prevent the screen from sleeping while watching", settings.keepScreenOn) { v ->
                onUpdate { it.copy(keepScreenOn = v) }
            }
        }
        item {
            SwitchRow("Open in landscape", "Rotate to landscape when the player starts", settings.landscapeOnStart) { v ->
                onUpdate { it.copy(landscapeOnStart = v) }
            }
        }
        item {
            ChoiceRow(
                "Default speed",
                listOf("0.5×" to 0.5f, "0.75×" to 0.75f, "1×" to 1f, "1.25×" to 1.25f, "1.5×" to 1.5f, "2×" to 2f),
                settings.defaultSpeed
            ) { v -> onUpdate { it.copy(defaultSpeed = v) } }
        }
        item {
            ChoiceRow(
                "Skip step (double-tap & buttons)",
                listOf("5s" to 5, "10s" to 10, "15s" to 15, "30s" to 30),
                settings.seekStepSec
            ) { v -> onUpdate { it.copy(seekStepSec = v) } }
        }

        item { Header("Data") }
        item {
            SwitchRow("Show cover images", "Turn off to save data", settings.showCovers) { v ->
                onUpdate { it.copy(showCovers = v) }
            }
        }

        item { Header("Storage") }
        item {
            ActionRow("Clear watch history", "Removes the “Recently opened” list", "↺") {
                confirm = "Clear watch history?" to onClearRecent
            }
        }
        item {
            ActionRow("Clear resume positions", "Videos will start from the beginning", "⏮") {
                confirm = "Clear all resume positions?" to onClearPositions
            }
        }
        item {
            ActionRow("Clear saved list", "Removes everything from Saved", "✕") {
                confirm = "Clear your saved list?" to onClearFavorites
            }
        }

        item {
            ActionRow("Reset settings", "Restore all playback options to defaults", "⟲") {
                confirm = "Reset all settings to default?" to { onUpdate { AppSettings() } }
            }
        }

        item { Header("Legal & About") }
        item { ActionRow("Licenses & attribution", "Credits for every title in the catalog", "©", onOpenLicenses) }
        item { ActionRow("Privacy policy", "What the app stores and what it shares", "🔒", onOpenPrivacy) }
        if (AppInfo.SUPPORT_EMAIL.isNotBlank()) {
            item {
                ActionRow("Send feedback", AppInfo.SUPPORT_EMAIL, "✉") {
                    val mail = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:${AppInfo.SUPPORT_EMAIL}")
                        putExtra(Intent.EXTRA_SUBJECT, "AnimeApp feedback ($versionName)")
                    }
                    runCatching { context.startActivity(mail) }
                }
            }
        }
        if (AppInfo.PRIVACY_POLICY_URL.isNotBlank()) {
            item { ActionRow("Privacy policy (online)", AppInfo.PRIVACY_POLICY_URL, "↗") { uriHandler.openUri(AppInfo.PRIVACY_POLICY_URL) } }
        }
        item { InfoRow("About", "AnimeApp • Version $versionName", "ⓘ") }
        item {
            Text(
                "This build plays only openly licensed sample titles. Offline downloads are not available yet.",
                color = Muted, lineHeight = 21.sp, fontSize = 13.sp
            )
        }
    }

    confirm?.let { (title, action) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) },
            text = { Text("This can't be undone.") },
            confirmButton = { TextButton(onClick = { action(); confirm = null }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun LicensesScreen(onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TextButton(onClick = onBack) { Text("‹  Back", color = TextPrimary, fontSize = 17.sp) }
            Text("Licenses & attribution", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Titles in this app are shown under their original licenses.", color = Muted)
        }
        items(AnimeCatalog.all, key = { it.id }) { a ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(a.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("License: ${a.licenseType.label}", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(a.attribution, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    a.licenseUrl?.let { u -> OutlinedButton(onClick = { uri.openUri(u) }) { Text("License") } }
                    OutlinedButton(onClick = { uri.openUri(a.officialSourceUrl) }) { Text("Source") }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Open-source libraries", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Jetpack Compose, AndroidX Media3 (ExoPlayer), Navigation, DataStore — Apache License 2.0. " +
                        "Coil — Apache License 2.0.",
                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp
                )
            }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(text.uppercase(), color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp,
        letterSpacing = 2.sp, modifier = Modifier.padding(top = 10.dp))
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
            .clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = OnAccent, checkedTrackColor = Accent
            )
        )
    }
}

@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, value) ->
                FilterChip(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Accent,
                        selectedLabelColor = OnAccent,
                        labelColor = TextPrimary
                    )
                )
            }
        }
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, icon: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Muted, fontSize = 26.sp)
    }
}

@Composable
private fun InfoRow(title: String, subtitle: String, icon: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun IconBadge(icon: String) {
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(ChipBg), contentAlignment = Alignment.Center) {
        Text(icon, color = Accent, fontSize = 20.sp)
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TextButton(onClick = onBack) { Text("‹  Back", color = TextPrimary, fontSize = 17.sp) }
            Text("Privacy policy", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        val sections = listOf(
            "No account, no tracking" to
                "AnimeApp does not require an account and contains no advertising, analytics or crash-reporting SDKs. We do not collect personal information.",
            "Stored on your device" to
                "Your saved titles, watch history, playback positions and settings are stored locally on your device only. You can erase them any time from Settings → Storage.",
            "Network requests" to
                "To play videos and show images the app connects to the servers that host them. Those servers can see your IP address and basic device/request information, as with any website. Their own privacy policies apply.",
            "Notifications" to
                "If you enable background playback, Android may ask for notification permission so playback controls can be shown. It is used for nothing else.",
            "Children" to
                "The app is not directed at children under 13 and does not knowingly collect their data.",
            "Changes" to
                "If this policy changes, the updated text will appear here with a new app version."
        )
        sections.forEach { (title, body) ->
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(body, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
                }
            }
        }
    }
}
