package com.elshatory.animeapp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.elshatory.animeapp.data.AnimePreferences
import com.elshatory.animeapp.data.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AnimeViewModel(private val preferences: AnimePreferences) : ViewModel() {
    private fun <T> kotlinx.coroutines.flow.Flow<T>.state(initial: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val favorites = preferences.favorites.state(emptySet())
    val recent = preferences.recent.state(emptyList())
    val positions = preferences.positions.state(emptyMap())
    private val _loaded = MutableStateFlow(false)
    /** True once the saved settings (theme etc.) have been read from disk. */
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()
    val settings = preferences.settings.onEach { _loaded.value = true }.state(AppSettings())

    fun toggleFavorite(id: Int) = viewModelScope.launch { preferences.toggleFavorite(id) }
    fun markWatched(id: Int) = viewModelScope.launch { preferences.markWatched(id) }
    fun savePosition(id: Int, ms: Long, durationMs: Long) =
        viewModelScope.launch { preferences.savePosition(id, ms, durationMs) }
    fun updateSettings(t: (AppSettings) -> AppSettings) =
        viewModelScope.launch { preferences.updateSettings(t) }
    fun clearRecent() = viewModelScope.launch { preferences.clearRecent() }
    fun clearFavorites() = viewModelScope.launch { preferences.clearFavorites() }
    fun clearPositions() = viewModelScope.launch { preferences.clearPositions() }

    companion object {
        fun factory(preferences: AnimePreferences) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                if (modelClass.isAssignableFrom(AnimeViewModel::class.java)) {
                    return AnimeViewModel(preferences) as T
                }
                throw IllegalArgumentException("Unknown ViewModel class")
            }
        }
    }
}
