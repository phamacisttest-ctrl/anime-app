package com.elshatory.animeapp

/**
 * Fill these in before publishing. Blank values simply hide the related Settings rows.
 * Google Play requires a public privacy-policy URL in the Play Console regardless.
 */
object AppInfo {
    /** e.g. "support@yourdomain.com" */
    val SUPPORT_EMAIL: String = ""

    /** e.g. "https://yourdomain.com/privacy" (host docs/PRIVACY_POLICY.md somewhere public). */
    val PRIVACY_POLICY_URL: String = ""
}
