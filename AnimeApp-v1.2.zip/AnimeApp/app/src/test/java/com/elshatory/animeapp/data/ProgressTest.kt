package com.elshatory.animeapp.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressTest {
    @Test fun parsesEmptyAndNull() {
        assertTrue(parseProgress(null).isEmpty())
        assertTrue(parseProgress("").isEmpty())
    }

    @Test fun parsesLegacyEntriesWithoutDuration() {
        val map = parseProgress("1:5000,2:120000")
        assertEquals(WatchProgress(5000, 0), map[1])
        assertEquals(WatchProgress(120000, 0), map[2])
    }

    @Test fun roundTrips() {
        val original = mapOf(1 to WatchProgress(5_000, 60_000), 3 to WatchProgress(42, 100))
        assertEquals(original, parseProgress(serializeProgress(original)))
    }

    @Test fun ignoresMalformedEntries() {
        val map = parseProgress("abc,1:x:3,2:10:20,:,5")
        assertEquals(mapOf(2 to WatchProgress(10, 20)), map)
    }

    @Test fun fractionIsClampedAndSafeWithoutDuration() {
        assertEquals(0f, WatchProgress(500, 0).fraction, 0f)
        assertEquals(1f, WatchProgress(900, 100).fraction, 0f)
        assertEquals(0.25f, WatchProgress(25, 100).fraction, 0.0001f)
        assertEquals(0L, WatchProgress(900, 100).remainingMs)
        assertEquals(75L, WatchProgress(25, 100).remainingMs)
    }
}
