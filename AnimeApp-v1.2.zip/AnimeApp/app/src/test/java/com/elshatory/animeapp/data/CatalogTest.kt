package com.elshatory.animeapp.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Release guard: a title must not be playable unless its license and attribution are filled in.
 * Add new catalog entries and this test tells you what is missing.
 */
class CatalogTest {
    @Test fun idsAreUnique() {
        val ids = AnimeCatalog.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun playableTitlesHaveVerifiedLicenseAndAttribution() {
        AnimeCatalog.all.filter { it.videoUrl != null }.forEach { a ->
            val who = "'${a.title}'"
            assertTrue("$who video must use https", a.videoUrl!!.startsWith("https://"))
            assertNotEquals("$who license is UNVERIFIED", LicenseType.UNVERIFIED, a.licenseType)
            assertTrue("$who needs attribution text", a.attribution.isNotBlank())
            assertTrue("$who needs an https licenseUrl", a.licenseUrl?.startsWith("https://") == true)
            assertTrue("$who needs an https source page", a.officialSourceUrl.startsWith("https://"))
        }
    }

    @Test fun optionalUrlsAreHttps() {
        AnimeCatalog.all.forEach { a ->
            a.coverUrl?.let { assertTrue("'${a.title}' cover must be https", it.startsWith("https://")) }
            a.subtitleUrl?.let { assertTrue("'${a.title}' subtitles must be https", it.startsWith("https://")) }
        }
    }

    @Test fun nonCommercialTitlesAreNotMonetizable() {
        AnimeCatalog.all.filter { it.licenseType == LicenseType.CC_BY_NC }
            .forEach { assertTrue("'${it.title}' is NC", !it.monetizationVerified) }
    }
}
