# AnimeApp

Kotlin + Jetpack Compose catalog and video-player app for openly licensed animation.

## Features
- Home, Discover (genres built from the catalog), Saved and Settings tabs
- Search by title or genre; details page with license & attribution block
- **Custom video player** (Media3/ExoPlayer, Compose controls)
  - play/pause, seek bar, skip back/forward (5/10/15/30 s), double-tap left/right to skip
  - speed 0.5×–2×, resize mode (fit / zoom / stretch), rotate, lock controls
  - swipe left = brightness, swipe right = volume
  - resume from last position, auto-hide controls, buffering indicator, error + retry
  - Picture-in-Picture, immersive mode, pauses when the app goes to background
- **Continue watching** on Home with progress bars; progress stored per title
- Optional subtitles (`subtitleUrl` on a title, CC button appears in the player), buffered-range display on the seek bar
- Share button, "More like this", sort options in Discover, fade transitions
- **Settings** (persisted with DataStore): autoplay, resume, gestures, keep screen on,
  landscape on start, default speed, skip step, cover images on/off,
  clear history / resume positions / saved list, reset to defaults
- **Licenses & attribution** screen

## Open
1. Open the `AnimeApp` folder in Android Studio, JDK 17, SDK Platform 36, sync Gradle, run `app`.
2. If Gradle can't resolve Media3 `1.11.1`, lower `media3` in `gradle/libs.versions.toml`.

## Catalog notes
- `coverUrl = null` shows a gradient placeholder. Add covers only from sources you have rights to.
- Morevna Ep. 3 has `videoUrl = null` until you paste the real file link from its official page.
- Only add titles whose license allows redistribution and fill in `attribution` / `licenseUrl`.
- Offline downloads, accounts and subtitles are not implemented.

## v1.2 — release readiness
- Themes: System / Dark / Light / AMOLED black, theme-aware status & navigation bars, splash screen, adaptive + themed icon
- Background playback via `PlaybackService` (Media3 MediaSession): media notification, lock-screen and headset controls
- Offline banner, in-app privacy policy, optional feedback / privacy-URL rows (`AppInfo.kt`)
- Release config: R8 + resource shrinking, signing via `keystore.properties`, backup rules, versioning
- Unit tests (progress parsing, catalog license guard) and a GitHub Actions workflow
- See `RELEASE.md` for the full checklist, `docs/` for the privacy policy and store-listing drafts
