# Release checklist

## A. Things only you can do (the code cannot do these)
1. **Content rights.** Ship only titles whose license allows redistribution. For each title fill in
   `licenseType`, `licenseUrl`, `attribution`, `officialSourceUrl` (see `Anime.kt`).
   `CatalogTest` fails if a playable title is missing any of them.
   - Morevna Ep. 3 has `videoUrl = null` — paste the official file link before shipping it.
   - Do not hot-link `commondatastorage.googleapis.com/gtv-videos-bucket` sample files in a
     commercial release; host copies yourself (Blender's licenses allow it) or use the project's own mirrors.
   - Covers: only official art/stills under the title's license, or leave `coverUrl = null`.
2. **Privacy policy URL.** Host `docs/PRIVACY_POLICY.md` publicly, put the URL in `AppInfo.PRIVACY_POLICY_URL`
   and in the Play Console. Also fill `AppInfo.SUPPORT_EMAIL`.
3. **Application ID.** `com.elshatory.animeapp` becomes permanent once published. Change it now if needed.
4. **Play Console:** developer account (one-time fee), Data safety form (answers: no data collected,
   no data shared — update if that changes), content rating questionnaire, target audience, store listing
   (`docs/STORE_LISTING.md`), screenshots.

## B. Signing
1. Create a keystore once: `keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias anime-release`
2. Copy `keystore.properties.example` → `keystore.properties`, fill it in. It is git-ignored.
3. **Back up the keystore and passwords.** (With Play App Signing you can recover an upload key, but don't rely on it.)

## C. Build
```
./gradlew testDebugUnitTest        # unit tests incl. catalog license guard
./gradlew lintDebug                # see app/build/reports/
./gradlew bundleRelease            # → app/build/outputs/bundle/release/app-release.aab
```
R8 minification and resource shrinking are on for release. **Test the release build on a real device**
(play a video, background playback, PiP, rotate, change theme) before uploading — minification bugs only show there.

## D. Roll-out
1. Upload the `.aab` to **Internal testing**, then Closed testing. New personal developer accounts must run a
   closed test with testers for a minimum period before production access — check Play Console's current requirement.
2. Bump `versionCode` (+1) and `versionName` in `app/build.gradle.kts` for every upload.
3. Staged roll-out to production (e.g. 10% → 50% → 100%), watching Play Console → Android vitals.

## E. Known gaps
- UI text is English only (no Arabic/other translations yet).
- No crash reporting beyond Play Console vitals. Add Firebase Crashlytics if you want detailed traces
  (and then update the privacy policy and Data safety form).
- No offline downloads, accounts, or multi-episode series.
