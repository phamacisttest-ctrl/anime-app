# Google Play listing — draft (edit before submitting)

**App name (max 30):** AnimeApp  _(check it is not already taken; consider a more distinctive name)_

**Short description (max 80):**
Watch openly licensed animation with a fast, polished player and a clean library.

**Full description (draft):**
AnimeApp is a clean catalog and player for openly licensed animated films and series.

• Smooth custom player — double-tap to skip, swipe for brightness and volume, speed control, subtitles when available, picture-in-picture
• Continue watching — pick up exactly where you stopped
• Save titles to your watchlist
• Light, dark and AMOLED themes
• Background audio with media controls
• No ads, no account, no tracking

Every title is shown with its license and attribution. Content is provided by its creators under open licenses (for example Creative Commons).

**Category:** Video Players & Editors  (or Entertainment)
**Contact email / website / privacy policy URL:** required by Play Console.

**Assets you must produce:** 512×512 icon, 1024×500 feature graphic, 2–8 phone screenshots (take them from the running app: Home, Details, Player, Settings).
