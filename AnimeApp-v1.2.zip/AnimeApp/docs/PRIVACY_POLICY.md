# Privacy Policy — AnimeApp

_Last updated: <DATE>_

**Contact:** <YOUR EMAIL>

AnimeApp does not require an account and does not collect personal information.
This policy describes exactly what the app does. Keep it in sync with the app: if you
add analytics, ads, sign-in or downloads, update this document **and** the Play Console
Data safety form.

## What stays on your device
Saved titles, watch history, playback positions and settings are stored locally
(Android DataStore). They are included in Android's standard device backup if you have it
enabled. You can erase them in **Settings → Storage**.

## What the app sends over the network
To stream videos and load images, the app connects to the servers that host that content
(for example `commondatastorage.googleapis.com`). Those servers receive your IP address and
standard request information, as with any website, and are governed by their own privacy
policies. AnimeApp itself operates no server and receives none of this data.

## What the app does not do
No advertising, no analytics or crash-reporting SDKs, no location, contacts, camera or
microphone access, and no sale or sharing of personal data.

## Notifications
If you turn on background playback, Android may ask for notification permission so playback
controls can be shown. It is used for nothing else.

## Children
The app is not directed at children under 13 and does not knowingly collect their data.

## Changes
Updates to this policy will be published with a new app version.
